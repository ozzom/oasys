def find_string(inputs):
    result = []
    words = ""
    for index,target in enumerate(inputs):
        if target.isdigit():
            if words != "":
                result.append(words)
            words = ""
        else: 
            words += inputs[index]
    return result

inputs = "cat32dog16cow5"
string_list = find_string(inputs)
print(string_list)