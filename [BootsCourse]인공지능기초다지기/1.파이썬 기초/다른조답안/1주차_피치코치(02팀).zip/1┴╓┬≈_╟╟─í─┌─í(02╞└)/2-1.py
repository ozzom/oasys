sentence = "way a is there will a is there Where"

def reverse_sentence(sentence):
    result = " ".join([i for i in sentence.split()[::-1]])

    return result

print(reverse_sentence(sentence))