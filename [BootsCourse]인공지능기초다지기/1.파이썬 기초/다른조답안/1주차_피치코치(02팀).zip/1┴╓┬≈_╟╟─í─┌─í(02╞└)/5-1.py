def find_string(inputs):
    result = inputs[:]
    for i in result:
        if i.isdigit():
            result = result.replace(i," ")

    return result.split()

inputs = "cat32dog16cow5"
string_list = find_string(inputs)
print(string_list)