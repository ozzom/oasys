sentence = "way a is there will a is there Where"

def reverse_sentence(sentence):
    temp = sentence.split()
    reverse_s = temp[::-1]
    
    return (' '.join(reverse_s))

print(reverse_sentence(sentence))