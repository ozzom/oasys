num_list = [1, 5, 7, 15, 16, 22, 28, 29]

def get_odd_num(num_list):
    return [i for i in num_list if i % 2 != 0]

print(get_odd_num(num_list))