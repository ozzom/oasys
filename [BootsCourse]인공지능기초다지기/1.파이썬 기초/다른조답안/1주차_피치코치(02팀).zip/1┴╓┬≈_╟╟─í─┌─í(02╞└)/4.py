dict_first = {'사과': 30, '배': 15, '감': 10, '포도': 10}
dict_second = {'사과': 5, '감': 25, '배': 15, '귤': 25}

def merge_dict(dict_first, dict_second):
    result_dict = {}
    for k1, v1 in dict_first.items():
        for k2, v2 in dict_second.items():
            if k1 == k2:
                result_dict[k1] = v1+v2
                # print(f"Appended 0 {k1} : {v1+v2}")
            else:
                if k1 not in dict_second:
                    result_dict[k1] = v1
                    # print(f"Appended 1 {k1} : {v1}")
                    break
                if k2 not in dict_first:
                    result_dict[k2] = v2
                    # print(f"Appended 2 {k2} : {v2}")
                    break


    print(result_dict)

merge_dict(dict_first, dict_second)