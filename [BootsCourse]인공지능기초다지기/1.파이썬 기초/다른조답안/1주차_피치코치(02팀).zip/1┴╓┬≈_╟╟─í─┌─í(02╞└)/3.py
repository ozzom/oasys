score = [(100, 100), (95, 90), (55, 60), (75, 80), (70, 70)]

def get_avg(score):
    for i, j in enumerate(score):
        print(f"{i+1} 번, 평균 : {(j[0]+j[1])/2}")

get_avg(score)